// deno-lint-ignore-file no-explicit-any
import { createClient } from 'npm:@supabase/supabase-js@2';
import { makeHandler } from './handler.js';

const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
  auth: { persistSession: false }
});
const dailyLimit = Number(Deno.env.get('AI_DAILY_LIMIT') ?? '80');

Deno.serve(makeHandler({
  allowedOrigin: Deno.env.get('ALLOWED_ORIGIN') ?? '*',
  models: {
    fast: Deno.env.get('MODEL_FAST') ?? 'claude-haiku-5-5',
    smart: Deno.env.get('MODEL_SMART') ?? 'claude-sonnet-5-5'
  },
  async getUser(token: string) {
    const { data, error } = await admin.auth.getUser(token);
    return error ? null : data.user;
  },
  async loadState(userId: string) {
    const { data } = await admin.from('app_state').select('state').eq('user_id', userId).maybeSingle();
    return (data as any)?.state ?? null;
  },
  async hasEntitlement(userId: string) {
    const { data } = await admin.from('entitlements').select('id').eq('user_id', userId).eq('product', 'masterclass').limit(1);
    return !!data?.length;
  },
  async bumpUsage(userId: string) {
    const day = new Date().toISOString().slice(0, 10);
    const { data, error } = await admin.rpc('bump_usage', { p_user: userId, p_day: day, p_limit: dailyLimit });
    if (error) throw error;
    return data === true;
  },
  anthropic(params: unknown) {
    return fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': Deno.env.get('ANTHROPIC_API_KEY')!,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify(params)
    });
  }
}));
