// Función `nemy`: único punto de entrada a Claude. La clave de la API vive solo aquí.
// Recibe { task, input, stream? }, valida a la persona, aplica el límite diario y devuelve texto o JSON.
// Las lecciones de la masterclass se cobran en el servidor: solo la del módulo 1 es gratis.
import { sanitize, build, extractJson } from '../_shared/prompts.js';

const TASKS = new Set(['suggest', 'steps', 'evaluate', 'design_master', 'lesson', 'chat']);

// Convierte el flujo SSE de Anthropic en eventos simples: data: {"delta":"..."} y data: [DONE]
export function toTextStream(body) {
  const dec = new TextDecoder();
  const enc = new TextEncoder();
  let buf = '';
  return body.pipeThrough(new TransformStream({
    transform(chunk, ctl) {
      buf += dec.decode(chunk, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        const line = block.split('\n').find((l) => l.startsWith('data:'));
        if (!line) continue;
        let ev;
        try { ev = JSON.parse(line.slice(5).trim()); } catch { continue; }
        if (ev.type === 'content_block_delta' && ev.delta && ev.delta.type === 'text_delta') {
          ctl.enqueue(enc.encode('data: ' + JSON.stringify({ delta: ev.delta.text }) + '\n\n'));
        } else if (ev.type === 'message_stop') {
          ctl.enqueue(enc.encode('data: [DONE]\n\n'));
        } else if (ev.type === 'error') {
          ctl.enqueue(enc.encode('data: ' + JSON.stringify({ error: 'upstream_error' }) + '\n\n'));
        }
      }
    }
  }));
}

export function makeHandler(deps) {
  const cors = {
    'Access-Control-Allow-Origin': deps.allowedOrigin || '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };
  const reply = (status, body) =>
    new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

  return async function handler(req) {
    try {
      if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
      if (req.method !== 'POST') return reply(405, { error: 'method_not_allowed' });

      const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
      const user = token ? await deps.getUser(token) : null;
      if (!user) return reply(401, { error: 'unauthorized' });

      let body;
      try { body = await req.json(); } catch { return reply(400, { error: 'invalid_json' }); }
      const task = body && body.task;
      if (!TASKS.has(task)) return reply(400, { error: 'unknown_task' });

      let input = sanitize(task, body.input);

      if (task === 'lesson') {
        // El contenido sale del estado guardado en el servidor, no de lo que envíe el navegador.
        const state = await deps.loadState(user.id);
        const master = state && state.master;
        const i = input.index;
        if (!master || !Array.isArray(master.modules) || !master.modules[i]) return reply(409, { error: 'master_not_saved' });
        if (i > 0 && !(await deps.hasEntitlement(user.id))) return reply(402, { error: 'payment_required' });
        input = sanitize('lesson', {
          index: i, topic: state.topic, name: state.name, mprofile: state.mprofile,
          log: state.log, xp: state.totalXp, master
        });
      }

      if (!(await deps.bumpUsage(user.id))) return reply(429, { error: 'rate_limited' });

      const spec = build(task, input);
      const wantStream = body.stream === true && spec.stream;
      let upstream;
      try {
        upstream = await deps.anthropic({
          model: deps.models[spec.tier], system: spec.system, messages: spec.messages,
          max_tokens: spec.maxTokens, stream: wantStream
        });
      } catch {
        return reply(502, { error: 'upstream_error' });
      }
      if (!upstream.ok) return reply(upstream.status === 429 ? 503 : 502, { error: 'upstream_error' });

      if (wantStream) {
        return new Response(toTextStream(upstream.body), {
          headers: { ...cors, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' }
        });
      }
      const data = await upstream.json();
      const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
      if (spec.json) {
        const parsed = extractJson(text);
        if (parsed == null) return reply(502, { error: 'invalid_model_output' });
        return reply(200, { data: parsed });
      }
      return reply(200, { text });
    } catch {
      return reply(500, { error: 'server_error' });
    }
  };
}
