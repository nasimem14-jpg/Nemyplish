// Función `create-checkout`: crea la sesión de pago de Stripe para la masterclass y devuelve su URL.
export function makeCheckoutHandler(deps) {
  const cors = {
    'Access-Control-Allow-Origin': deps.allowedOrigin || '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };
  const reply = (status, body) =>
    new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

  return async function handler(req) {
    try {
      if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
      if (req.method !== 'POST') return reply(405, { error: 'method_not_allowed' });

      const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
      const user = token ? await deps.getUser(token) : null;
      if (!user) return reply(401, { error: 'unauthorized' });

      if (await deps.hasEntitlement(user.id)) return reply(200, { already: true });

      const form = new URLSearchParams({
        mode: 'payment',
        'line_items[0][price]': deps.priceId,
        'line_items[0][quantity]': '1',
        client_reference_id: user.id,
        success_url: deps.siteUrl + '?paid=1',
        cancel_url: deps.siteUrl + '?paid=0'
      });
      if (user.email) form.set('customer_email', user.email);

      const res = await deps.stripe(form);
      if (!res.ok) return reply(502, { error: 'stripe_error' });
      const session = await res.json();
      if (!session.url) return reply(502, { error: 'stripe_error' });
      return reply(200, { url: session.url });
    } catch {
      return reply(500, { error: 'server_error' });
    }
  };
}
