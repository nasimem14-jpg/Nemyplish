import { createClient } from 'npm:@supabase/supabase-js@2';
import { makeCheckoutHandler } from './handler.js';

const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
  auth: { persistSession: false }
});

Deno.serve(makeCheckoutHandler({
  allowedOrigin: Deno.env.get('ALLOWED_ORIGIN') ?? '*',
  priceId: Deno.env.get('STRIPE_PRICE_ID')!,
  siteUrl: Deno.env.get('SITE_URL')!,
  async getUser(token: string) {
    const { data, error } = await admin.auth.getUser(token);
    return error ? null : data.user;
  },
  async hasEntitlement(userId: string) {
    const { data } = await admin.from('entitlements').select('id').eq('user_id', userId).eq('product', 'masterclass').limit(1);
    return !!data?.length;
  },
  stripe(form: URLSearchParams) {
    return fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + Deno.env.get('STRIPE_SECRET_KEY')!,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: form
    });
  }
}));
