import { createClient } from 'npm:@supabase/supabase-js@2';
import { makeWebhookHandler } from './handler.js';

const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
  auth: { persistSession: false }
});

Deno.serve(makeWebhookHandler({
  secret: Deno.env.get('STRIPE_WEBHOOK_SECRET')!,
  async grant(userId: string, sessionId: string) {
    // upsert con ignoreDuplicates: si Stripe reenvía el evento, no pasa nada.
    const { error } = await admin
      .from('entitlements')
      .upsert({ user_id: userId, product: 'masterclass', stripe_session_id: sessionId }, { onConflict: 'stripe_session_id', ignoreDuplicates: true });
    if (error && error.code !== '23505') throw error;
  }
}));
