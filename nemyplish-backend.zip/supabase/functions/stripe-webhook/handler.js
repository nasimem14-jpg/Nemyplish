// Función `stripe-webhook`: cuando Stripe confirma un pago, concede la masterclass a esa persona.
import { verifyStripeSignature } from '../_shared/stripe.js';

export function makeWebhookHandler(deps) {
  const reply = (status, body) =>
    new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

  return async function handler(req) {
    if (req.method !== 'POST') return reply(405, { error: 'method_not_allowed' });
    const payload = await req.text();
    const ok = await verifyStripeSignature(payload, req.headers.get('stripe-signature'), deps.secret, { now: deps.now?.() });
    if (!ok) return reply(400, { error: 'invalid_signature' });

    let event;
    try { event = JSON.parse(payload); } catch { return reply(400, { error: 'invalid_json' }); }

    const paidTypes = ['checkout.session.completed', 'checkout.session.async_payment_succeeded'];
    if (paidTypes.includes(event.type)) {
      const s = event.data && event.data.object;
      if (s && s.payment_status === 'paid' && s.client_reference_id) {
        try {
          await deps.grant(s.client_reference_id, s.id);
        } catch {
          return reply(500, { error: 'grant_failed' }); // Stripe reintenta el envío
        }
      }
    }
    return reply(200, { received: true });
  };
}
