-- Nemyplish: esquema inicial.
-- Estado del recorrido por usuario, compras (masterclass) y límite diario de uso de IA.

-- 1) Estado del recorrido (lo escribe el propio usuario).
create table public.app_state (
  user_id uuid primary key references auth.users (id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.app_state enable row level security;

create policy "app_state: leer lo propio" on public.app_state
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "app_state: crear lo propio" on public.app_state
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "app_state: actualizar lo propio" on public.app_state
  for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "app_state: borrar lo propio" on public.app_state
  for delete to authenticated using ((select auth.uid()) = user_id);

-- 2) Compras. Solo la función stripe-webhook (rol de servicio) puede escribir.
--    El usuario puede leer las suyas, pero no crearlas ni modificarlas.
create table public.entitlements (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  product text not null default 'masterclass',
  stripe_session_id text not null unique,
  created_at timestamptz not null default now(),
  unique (user_id, product)
);

alter table public.entitlements enable row level security;

create policy "entitlements: leer lo propio" on public.entitlements
  for select to authenticated using ((select auth.uid()) = user_id);

-- 3) Uso diario de IA, para limitar el coste por persona. Sin políticas: solo rol de servicio.
create table public.ai_usage (
  user_id uuid not null references auth.users (id) on delete cascade,
  day date not null,
  count integer not null default 0,
  primary key (user_id, day)
);

alter table public.ai_usage enable row level security;

-- Suma 1 al contador del día y devuelve false si ya se alcanzó el límite (operación atómica).
create or replace function public.bump_usage(p_user uuid, p_day date, p_limit integer)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  c integer;
begin
  insert into public.ai_usage as u (user_id, day, count)
  values (p_user, p_day, 1)
  on conflict (user_id, day) do update set count = u.count + 1
  where u.count < p_limit
  returning u.count into c;
  return c is not null;
end;
$$;

revoke all on function public.bump_usage(uuid, date, integer) from public, anon, authenticated;
grant execute on function public.bump_usage(uuid, date, integer) to service_role;
